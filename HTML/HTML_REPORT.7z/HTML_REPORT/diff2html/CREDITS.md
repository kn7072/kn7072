# Credits

This is the list of all the kind people that have contributed to the diff2html project.
This list is ordered by first contribution.

Thanks,
@rtfpessoa

----------

Rodrigo Fernandes, [@rtfpessoa](https://github.com/rtfpessoa)

JK Kim, [@codingtwinky](https://github.com/codingtwinky)

Paulo Bu, [@pbu88](https://github.com/pbu88)

Nuno Teixeira, [@nmatpt](https://github.com/nmatpt)

Mikko Rantanen, [@Rantanen](https://github.com/Rantanen)

Wolfgang Illmeyer, [@escitalopram](https://github.com/escitalopram)

Jameskmonger, [@Jameskmonger](https://github.com/Jameskmonger)

Rafael Cortês, [@mrfyda](https://github.com/mrfyda)

Ivan Vorontsov, [@lantian](https://github.com/lantian)
